using System.Data;

namespace AD_TH05_Valentyno
{
    public partial class Form1 : Form
    {
        DataTable dataSimpan = new DataTable();
        DataTable Category = new DataTable();
        DataTable dataProduct = new DataTable();
        int Cat = 6;
        int selectedCat = 0;
        int selectedIndex = 0;
        public Form1()
        {
            InitializeComponent();
        }

        private void button5_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            cb_pilihfilter.Enabled = false;
            dataSimpan.Columns.Add("ID Product");
            dataSimpan.Columns.Add("Nama Product");
            dataSimpan.Columns.Add("Harga");
            dataSimpan.Columns.Add("Stock");
            dataSimpan.Columns.Add("ID Category");
            dataSimpan.Rows.Add("J001", "Jas Hitam", 100000, 10, "C1");
            dataSimpan.Rows.Add("T001", "T-Shirt Black Pink", 70000, 20, "C2");
            dataSimpan.Rows.Add("T002", "T-Shirt Obsessive", 75000, 16, "C2");
            dataSimpan.Rows.Add("R001", "Rok Mini", 82000, 26, "C3");
            dataSimpan.Rows.Add("J002", "Jeans Biru", 90000, 5, "C4");
            dataSimpan.Rows.Add("C001", "Celana Pendek Coklat", 60000, 11, "C4");
            dataSimpan.Rows.Add("C002", "Cawat Blink-Blink", 1000000, 1, "C5");
            dataSimpan.Rows.Add("R002", "Rocca Shirt", 50000, 8, "C2");

            Category.Columns.Add("ID Category");
            Category.Columns.Add("Nama Category");
            Category.Rows.Add("C1", "Jas");
            Category.Rows.Add("C2", "T-Shirt");
            Category.Rows.Add("C3", "Rok");
            Category.Rows.Add("C4", "Celana");
            Category.Rows.Add("C5", "Cawat");

            dataProduct = dataSimpan;

            cb_DCategory.DataSource = Category;
            cb_DCategory.DisplayMember = "Nama Category";
            dtg_Proudct.DataSource = dataProduct;
            dtg_Category.DataSource = Category;
            cb_DCategory.Text = "";
        }

        private void bt_AddCategory_Click(object sender, EventArgs e)
        {

            if (tb_CNama.Text == "")
            {
                MessageBox.Show("eror");
            }
            else
            {
                bool cek = false;
                for (int i = 0; i < Category.Rows.Count; i++)
                {
                    if (Category.Rows[i][1].ToString() == tb_CNama.Text)
                    {
                        cek = true;
                        break;
                    }
                }
                if (cek == true)
                {
                    MessageBox.Show("Category Already Exist");
                }
                else
                {
                    Category.Rows.Add("C" + Cat, tb_CNama.Text);
                    Cat++;
                    tb_CNama.Text = "";
                }
            }
        }

        private void bt_Filter_Click(object sender, EventArgs e)
        {
            cb_pilihfilter.Enabled = true;
            cb_pilihfilter.DataSource = Category;
            cb_pilihfilter.DisplayMember = "Nama Category";
        }

        private void bt_All_Click(object sender, EventArgs e)
        {
            cb_pilihfilter.Enabled = false;
            dataProduct = dataSimpan;
            dtg_Proudct.DataSource = dataProduct;
            cb_pilihfilter.Text = "";
        }

        private void cb_pilihfilter_SelectedIndexChanged(object sender, EventArgs e)
        {
            dataProduct = new DataTable();
            int index = cb_pilihfilter.SelectedIndex;
            dataProduct.Columns.Add("ID Product");
            dataProduct.Columns.Add("Nama Product");
            dataProduct.Columns.Add("Harga");
            dataProduct.Columns.Add("Stock");
            dataProduct.Columns.Add("ID Category");
            foreach (DataRow x in dataSimpan.Rows)
            {
                if (x["ID Category"] == Category.Rows[index]["ID Category"].ToString())
                {
                    dataProduct.Rows.Add(x["ID Product"], x["Nama Product"], x["Harga"], x["Stock"], x  ["ID Category"]);
                }
            }
            if (cb_pilihfilter.Enabled == false)
            {

            }
            else
            {
                dtg_Proudct.DataSource = dataProduct;
            }
            
        }

        private void bt_RemoveCategory_Click(object sender, EventArgs e)
        {
            if (tb_CNama.Text == "")
            {
                MessageBox.Show("Pastikan ada yang terpilih");
            }
            else
            {
                string catRemove = Category.Rows[selectedCat]["ID Category"].ToString();
                Category.Rows.RemoveAt(selectedCat);
                dtg_Category.DataSource = Category;
                cb_DCategory.DataSource = Category;
                cb_DCategory.DisplayMember = "Nama Category";

                List<int> removeIdx = new List<int>();
                for (int i = 0; i < dataSimpan.Rows.Count; i++)
                {
                    if (dataSimpan.Rows[i]["ID Category"].ToString() == catRemove)
                    {
                        removeIdx.Add(i);
                    }
                }

                foreach (int j in removeIdx)
                {
                    removeItem(catRemove);
                }

                dataProduct = dataSimpan;
                dtg_Proudct.DataSource = dataProduct;
            }
        }
        private void removeItem(string catRemove)
        {
            List<int> removeIdx = new List<int>();
            for (int i = 0; i < dataSimpan.Rows.Count; i++)
            {
                if (dataSimpan.Rows[i]["ID Category"].ToString() == catRemove)
                {
                    removeIdx.Add(i);
                    break;
                }
            }
            dataSimpan.Rows.RemoveAt(removeIdx[0]);
        }

        private string numbering(char x)
        {
            int count = 0;
            foreach (DataRow dr in dataSimpan.Rows)
            {
                if (dr["ID Product"].ToString()[0] == x)
                {
                    count++;
                }
            }
            count++;
            return x.ToString() + count.ToString("000");
        }
        private void bt_addproduct_detail_Click(object sender, EventArgs e)
        {
            if (tb_DNama.Text == "" || tb_DStock.Text == "" || tb_DHarga.Text == "" || cb_DCategory.Text == "")
            {
                MessageBox.Show("Pastikan Semua Terisi");
            }
            else
            {
                string result = numbering(tb_DNama.Text.ToUpper()[0]);
                int index = cb_DCategory.SelectedIndex;
                dataSimpan.Rows.Add(result, tb_DNama.Text, tb_DHarga.Text, tb_DStock.Text, Category.Rows[index]["ID Category"]);
                dataProduct = dataSimpan;
                dtg_Proudct.DataSource = dataProduct;
                tb_DNama.Text = "";
                tb_DStock.Text = "";
                tb_DHarga.Text = "";
                cb_DCategory.Text = "";
            }
        }

        private void bt_EditProduct_detail_Click(object sender, EventArgs e)
        {
            if (tb_DNama.Text == "" || tb_DStock.Text == "" || tb_DHarga.Text == "" ||cb_DCategory.Text == "")
            {
                MessageBox.Show("Pastikan Semua Terisi");
            }
            else
            {
                if (Convert.ToInt32(tb_DStock.Text) == 0)
                {
                    dataSimpan.Rows.RemoveAt(selectedIndex);
                }
                else
                {
                    dataSimpan.Rows[selectedIndex]["Nama Product"] = tb_DNama.Text;
                    dataSimpan.Rows[selectedIndex]["Harga"] = tb_DHarga.Text;
                    dataSimpan.Rows[selectedIndex]["Stock"] = tb_DStock.Text;
                    dataSimpan.Rows[selectedIndex]["ID Category"] = Category.Rows[cb_DCategory.SelectedIndex]["ID Category"];
                }
                dataProduct = dataSimpan;
                dtg_Proudct.DataSource = dataProduct;

                tb_DNama.Text = "";
                tb_DHarga.Text = "";
                tb_DStock.Text = "";
                cb_DCategory.SelectedIndex = -1;
            }
        }

        private void bt_Remove_Detail_Click(object sender, EventArgs e)
        {
            if (tb_DNama.Text == "" || tb_DStock.Text == "" || tb_DHarga.Text == "" || cb_DCategory.Text == "")
            {

            }
            else
            {
                string catRemove = Category.Rows[selectedCat]["ID Category"].ToString();
                Category.Rows.RemoveAt(selectedCat);
                dtg_Category.DataSource = Category;
                cb_DCategory.DataSource = Category;
                cb_DCategory.DisplayMember = "Nama Category";

                List<int> removeIdx = new List<int>();
                for (int i = 0; i < dataSimpan.Rows.Count; i++)
                {
                    if (dataSimpan.Rows[i]["ID Category"].ToString() == catRemove)
                    {
                        removeIdx.Add(i);
                    }
                }

                foreach (int j in removeIdx)
                {
                    removeItem(catRemove);
                }

                dataProduct = dataSimpan;
                dtg_Proudct.DataSource = dataProduct;
                tb_DNama.Text = "";
                tb_DStock.Text = "";
                tb_DHarga.Text = "";
                cb_DCategory.Text = "";
            }
        }
        private void dtg_Category_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && e.ColumnIndex >= 0)
            {
                DataGridViewRow selectedRow = dtg_Category.Rows[e.RowIndex];
                tb_CNama.Text = selectedRow.Cells["Nama Category"].Value.ToString();
                selectedCat = e.RowIndex;
            }
        }

        private void dtg_Proudct_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && e.ColumnIndex >= 0)
            {
                DataGridViewRow selectedRow = dtg_Proudct.Rows[e.RowIndex];
                tb_DNama.Text = selectedRow.Cells["Nama Product"].Value.ToString();
                tb_DHarga.Text = selectedRow.Cells["Harga"].Value.ToString();
                tb_DStock.Text = selectedRow.Cells["Stock"].Value.ToString();

                string idCat = selectedRow.Cells["ID Category"].Value.ToString();


                for (int i = 0; i < Category.Rows.Count; i++)
                {
                    if (Category.Rows[i]["ID Category"].ToString() == idCat)
                    {
                        cb_DCategory.SelectedIndex = i;
                        selectedIndex = i;
                    }
                }
            }
        }

        private void tb_DHarga_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void tb_DStock_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }
    }
}
