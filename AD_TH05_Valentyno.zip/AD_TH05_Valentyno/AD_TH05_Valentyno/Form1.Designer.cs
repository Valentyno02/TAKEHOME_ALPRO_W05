﻿namespace AD_TH05_Valentyno
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            dtg_Proudct = new DataGridView();
            dtg_Category = new DataGridView();
            bt_All = new Button();
            bt_Filter = new Button();
            cb_pilihfilter = new ComboBox();
            tb_CNama = new TextBox();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            label7 = new Label();
            label8 = new Label();
            tb_DNama = new TextBox();
            tb_DHarga = new TextBox();
            tb_DStock = new TextBox();
            cb_DCategory = new ComboBox();
            bt_addproduct_detail = new Button();
            bt_EditProduct_detail = new Button();
            bt_Remove_Detail = new Button();
            bt_AddCategory = new Button();
            bt_RemoveCategory = new Button();
            ((System.ComponentModel.ISupportInitialize)dtg_Proudct).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dtg_Category).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold, GraphicsUnit.Point);
            label1.Location = new Point(25, 10);
            label1.Name = "label1";
            label1.Size = new Size(96, 30);
            label1.TabIndex = 0;
            label1.Text = "Product";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold, GraphicsUnit.Point);
            label2.Location = new Point(662, 16);
            label2.Name = "label2";
            label2.Size = new Size(109, 30);
            label2.TabIndex = 1;
            label2.Text = "Category";
            // 
            // dtg_Proudct
            // 
            dtg_Proudct.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dtg_Proudct.Location = new Point(25, 50);
            dtg_Proudct.Margin = new Padding(3, 2, 3, 2);
            dtg_Proudct.Name = "dtg_Proudct";
            dtg_Proudct.RowHeadersWidth = 51;
            dtg_Proudct.RowTemplate.Height = 29;
            dtg_Proudct.Size = new Size(612, 185);
            dtg_Proudct.TabIndex = 2;
            dtg_Proudct.CellClick += dtg_Proudct_CellClick;
            // 
            // dtg_Category
            // 
            dtg_Category.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dtg_Category.Location = new Point(662, 50);
            dtg_Category.Margin = new Padding(3, 2, 3, 2);
            dtg_Category.Name = "dtg_Category";
            dtg_Category.RowHeadersWidth = 51;
            dtg_Category.RowTemplate.Height = 29;
            dtg_Category.Size = new Size(279, 141);
            dtg_Category.TabIndex = 3;
            dtg_Category.CellClick += dtg_Category_CellClick;
            // 
            // bt_All
            // 
            bt_All.Location = new Point(140, 16);
            bt_All.Margin = new Padding(3, 2, 3, 2);
            bt_All.Name = "bt_All";
            bt_All.Size = new Size(57, 19);
            bt_All.TabIndex = 4;
            bt_All.Text = "All";
            bt_All.UseVisualStyleBackColor = true;
            bt_All.Click += bt_All_Click;
            // 
            // bt_Filter
            // 
            bt_Filter.Location = new Point(202, 16);
            bt_Filter.Margin = new Padding(3, 2, 3, 2);
            bt_Filter.Name = "bt_Filter";
            bt_Filter.Size = new Size(57, 19);
            bt_Filter.TabIndex = 5;
            bt_Filter.Text = "Filter";
            bt_Filter.UseVisualStyleBackColor = true;
            bt_Filter.Click += bt_Filter_Click;
            // 
            // cb_pilihfilter
            // 
            cb_pilihfilter.FormattingEnabled = true;
            cb_pilihfilter.Location = new Point(272, 15);
            cb_pilihfilter.Margin = new Padding(3, 2, 3, 2);
            cb_pilihfilter.Name = "cb_pilihfilter";
            cb_pilihfilter.Size = new Size(76, 23);
            cb_pilihfilter.TabIndex = 6;
            cb_pilihfilter.SelectedIndexChanged += cb_pilihfilter_SelectedIndexChanged;
            // 
            // tb_CNama
            // 
            tb_CNama.Location = new Point(727, 202);
            tb_CNama.Margin = new Padding(3, 2, 3, 2);
            tb_CNama.Name = "tb_CNama";
            tb_CNama.Size = new Size(204, 23);
            tb_CNama.TabIndex = 7;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(673, 204);
            label3.Name = "label3";
            label3.Size = new Size(45, 15);
            label3.TabIndex = 8;
            label3.Text = "Name :";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold, GraphicsUnit.Point);
            label4.Location = new Point(25, 241);
            label4.Name = "label4";
            label4.Size = new Size(84, 30);
            label4.TabIndex = 9;
            label4.Text = "Details";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(21, 274);
            label5.Name = "label5";
            label5.Size = new Size(48, 15);
            label5.TabIndex = 10;
            label5.Text = "Nama : ";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(4, 298);
            label6.Name = "label6";
            label6.Size = new Size(61, 15);
            label6.TabIndex = 11;
            label6.Text = "Category :";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(21, 323);
            label7.Name = "label7";
            label7.Size = new Size(45, 15);
            label7.TabIndex = 12;
            label7.Text = "Harga :";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(21, 348);
            label8.Name = "label8";
            label8.Size = new Size(42, 15);
            label8.TabIndex = 13;
            label8.Text = "Stock :";
            // 
            // tb_DNama
            // 
            tb_DNama.Location = new Point(79, 272);
            tb_DNama.Margin = new Padding(3, 2, 3, 2);
            tb_DNama.Name = "tb_DNama";
            tb_DNama.Size = new Size(337, 23);
            tb_DNama.TabIndex = 14;
            // 
            // tb_DHarga
            // 
            tb_DHarga.Location = new Point(79, 321);
            tb_DHarga.Margin = new Padding(3, 2, 3, 2);
            tb_DHarga.Name = "tb_DHarga";
            tb_DHarga.Size = new Size(110, 23);
            tb_DHarga.TabIndex = 16;
            tb_DHarga.KeyPress += tb_DHarga_KeyPress;
            // 
            // tb_DStock
            // 
            tb_DStock.Location = new Point(79, 346);
            tb_DStock.Margin = new Padding(3, 2, 3, 2);
            tb_DStock.Name = "tb_DStock";
            tb_DStock.Size = new Size(110, 23);
            tb_DStock.TabIndex = 17;
            tb_DStock.KeyPress += tb_DStock_KeyPress;
            // 
            // cb_DCategory
            // 
            cb_DCategory.FormattingEnabled = true;
            cb_DCategory.Location = new Point(79, 296);
            cb_DCategory.Margin = new Padding(3, 2, 3, 2);
            cb_DCategory.Name = "cb_DCategory";
            cb_DCategory.Size = new Size(110, 23);
            cb_DCategory.TabIndex = 18;
            // 
            // bt_addproduct_detail
            // 
            bt_addproduct_detail.BackColor = Color.Lime;
            bt_addproduct_detail.Location = new Point(216, 320);
            bt_addproduct_detail.Margin = new Padding(3, 2, 3, 2);
            bt_addproduct_detail.Name = "bt_addproduct_detail";
            bt_addproduct_detail.Size = new Size(63, 44);
            bt_addproduct_detail.TabIndex = 19;
            bt_addproduct_detail.Text = "Add Product";
            bt_addproduct_detail.UseVisualStyleBackColor = false;
            bt_addproduct_detail.Click += bt_addproduct_detail_Click;
            // 
            // bt_EditProduct_detail
            // 
            bt_EditProduct_detail.BackColor = Color.Yellow;
            bt_EditProduct_detail.Location = new Point(284, 320);
            bt_EditProduct_detail.Margin = new Padding(3, 2, 3, 2);
            bt_EditProduct_detail.Name = "bt_EditProduct_detail";
            bt_EditProduct_detail.Size = new Size(63, 44);
            bt_EditProduct_detail.TabIndex = 20;
            bt_EditProduct_detail.Text = "Edit Product";
            bt_EditProduct_detail.UseVisualStyleBackColor = false;
            bt_EditProduct_detail.Click += bt_EditProduct_detail_Click;
            // 
            // bt_Remove_Detail
            // 
            bt_Remove_Detail.BackColor = Color.Red;
            bt_Remove_Detail.Location = new Point(353, 320);
            bt_Remove_Detail.Margin = new Padding(3, 2, 3, 2);
            bt_Remove_Detail.Name = "bt_Remove_Detail";
            bt_Remove_Detail.Size = new Size(63, 44);
            bt_Remove_Detail.TabIndex = 21;
            bt_Remove_Detail.Text = "Remove Product";
            bt_Remove_Detail.UseVisualStyleBackColor = false;
            bt_Remove_Detail.Click += bt_Remove_Detail_Click;
            // 
            // bt_AddCategory
            // 
            bt_AddCategory.BackColor = Color.Lime;
            bt_AddCategory.Location = new Point(727, 235);
            bt_AddCategory.Margin = new Padding(3, 2, 3, 2);
            bt_AddCategory.Name = "bt_AddCategory";
            bt_AddCategory.Size = new Size(77, 44);
            bt_AddCategory.TabIndex = 22;
            bt_AddCategory.Text = "Add Category";
            bt_AddCategory.UseVisualStyleBackColor = false;
            bt_AddCategory.Click += bt_AddCategory_Click;
            // 
            // bt_RemoveCategory
            // 
            bt_RemoveCategory.BackColor = Color.Red;
            bt_RemoveCategory.Location = new Point(809, 235);
            bt_RemoveCategory.Margin = new Padding(3, 2, 3, 2);
            bt_RemoveCategory.Name = "bt_RemoveCategory";
            bt_RemoveCategory.Size = new Size(77, 44);
            bt_RemoveCategory.TabIndex = 23;
            bt_RemoveCategory.Text = "Remove Category";
            bt_RemoveCategory.UseVisualStyleBackColor = false;
            bt_RemoveCategory.Click += bt_RemoveCategory_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(255, 192, 255);
            ClientSize = new Size(1052, 380);
            Controls.Add(bt_RemoveCategory);
            Controls.Add(bt_AddCategory);
            Controls.Add(bt_Remove_Detail);
            Controls.Add(bt_EditProduct_detail);
            Controls.Add(bt_addproduct_detail);
            Controls.Add(cb_DCategory);
            Controls.Add(tb_DStock);
            Controls.Add(tb_DHarga);
            Controls.Add(tb_DNama);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(tb_CNama);
            Controls.Add(cb_pilihfilter);
            Controls.Add(bt_Filter);
            Controls.Add(bt_All);
            Controls.Add(dtg_Category);
            Controls.Add(dtg_Proudct);
            Controls.Add(label2);
            Controls.Add(label1);
            Margin = new Padding(3, 2, 3, 2);
            Name = "Form1";
            Text = "Toko";
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)dtg_Proudct).EndInit();
            ((System.ComponentModel.ISupportInitialize)dtg_Category).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private DataGridView dtg_Proudct;
        private DataGridView dtg_Category;
        private Button bt_All;
        private Button bt_Filter;
        private ComboBox cb_pilihfilter;
        private TextBox tb_CNama;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private Label label7;
        private Label label8;
        private TextBox tb_DNama;
        private TextBox tb_DHarga;
        private TextBox tb_DStock;
        private ComboBox cb_DCategory;
        private Button bt_addproduct_detail;
        private Button bt_EditProduct_detail;
        private Button bt_Remove_Detail;
        private Button bt_AddCategory;
        private Button bt_RemoveCategory;
    }
}